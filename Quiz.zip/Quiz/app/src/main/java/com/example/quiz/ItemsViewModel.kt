package com.example.quiztestapp

data class ItemsViewModel(
    val image: Int,
    val questionText: String,
    val option1:String,
    val option2:String,
    val option3:String,
    val option4:String,
    val rightAnstion:String,
    )